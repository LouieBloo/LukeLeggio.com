#ifndef SLOWZOMBIE_H
#define SLOWZOMBIE_H
#include "Unit.h"
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "Timer.h"
#include <stack>
#include "Projectile.h"
class SlowZombie: public Unit
{
    public:
        SlowZombie(int x,int y);
        SDL_Surface * draw();
        int getXLocation();
        int getYLocation();
        int getWidth();
        int getHeight();
        int attack();
        bool isDestroyed();
        int getId();

        void cleanup();
    protected:
    private:
        SDL_Surface* picture;
        int width;
        int height;
        double locationX;
        double locationY;
        double angle;

        stack<Projectile*> collidedProjectiles;

        int damage;
        double moveSpeed;
        int attackSpeed;
        Timer * blowBack;
        Timer * update;
        int updateSpeed;
        int health;
        bool destroyed;
        int id;

        int frame;
        Timer * animationTimer;

        SDL_Surface *images[3];
};

#endif // SLOWZOMBIE_H
