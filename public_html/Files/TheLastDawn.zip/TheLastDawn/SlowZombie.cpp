#include "SlowZombie.h"
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "ImageLoader.h"
#include "Collision.h"
#include "Timer.h"
#include <math.h>
#include <iostream>
#include "Player.h"
extern ImageLoader * imageHandler;
extern Collision* collisionDetection;
extern SDL_Rect camera;
extern Player * player;

extern int bullshit;
SlowZombie::SlowZombie(int x, int y)
{
    //picture = imageHandler->optimizeImage("images/zombieImages/slowZombie.png");
    images[0] = imageHandler->optimizeImage("images/level1Images/player/animation/player1.png");
    images[1] = imageHandler->optimizeImage("images/level1Images/player/animation/player2.png");
    images[2] = imageHandler->optimizeImage("images/level1Images/player/animation/player3.png");


    id = bullshit;
    bullshit++;


    locationX = x;
    locationY = y;
    width = 50;
    height = 50;
    moveSpeed = 1;
    updateSpeed = 15;
    damage = 5;
    attackSpeed = 1;

    health = 5;

    destroyed = false;

    animationTimer = new Timer();
    animationTimer->start();

    update = new Timer();
    update->start();

    frame = 0;

    blowBack = new Timer();
    blowBack->start();
}

SDL_Surface * SlowZombie::draw()
{

    //PROJECTILE COLLISION
    if(health<=0)
    {
        destroyed = true;
    }
    else
    {
        collidedProjectiles = collisionDetection->projectileCollision(getXLocation(),getYLocation(),width,height);
        while(collidedProjectiles.size()>0)
        {
            if(health>0)
            {

                health+= -collidedProjectiles.top()->getDamage();
                collidedProjectiles.top()->destroy();
            }
            else
            {
                destroyed = true;
            }
            collidedProjectiles.pop();

        }
    }


    //PATHING COLLISIONddddddddddmeow
    if(update->getTime()>updateSpeed&&!(getXLocation()+300<player->getXLocation()+25)&&!(getXLocation()-300>player->getXLocation()+25)&&!(getYLocation()+300<player->getYLocation()+25)&&!(getYLocation()-300>player->getYLocation()+25))//making sure they are in vicinity of the player, will eventually change this to a status. such as alerterd
    {
//        if(!collisionDetection->pathingCollision(getXLocation(),getYLocation()+moveSpeed,width,height))
//        {
            angle = atan2(-15+getYLocation()-player->getYLocation(),(player->getXLocation()-getXLocation()+15));



            if(!collisionDetection->unitCollision2(getXLocation(),getYLocation()+(-1*moveSpeed*sin(angle)),width,height,this))
            {
                locationY = locationY + -1*moveSpeed*sin(angle);
            }
            if(!collisionDetection->unitCollision2(getXLocation()+(moveSpeed*cos(angle)),getYLocation(),width,height,this))
            {
                locationX = locationX + moveSpeed*cos(angle);
            }


            update->start();
//        }
    }



    //ANIMATION
    if(animationTimer->getTime()>300)
    {
        if(frame>=2)
        {
            frame = 0;
        }
        else
        {
            frame++;
        }
        animationTimer->start();
    }

    return images[frame];

}

int SlowZombie::attack()
{
    if(blowBack->getTime()>=(1000*attackSpeed))
    {
        blowBack->start();
        return damage;
    }
    return 0;

}

int SlowZombie::getXLocation()
{
    return locationX-camera.x;
}
int SlowZombie::getYLocation()
{
    return locationY-camera.y;
}
int SlowZombie::getWidth()
{
    return width;
}
int SlowZombie::getHeight()
{
    return height;
}

bool SlowZombie::isDestroyed()
{
    return destroyed;
}

int SlowZombie::getId()
{
    return id;
}

void SlowZombie::cleanup()
{
    SDL_FreeSurface(picture);
    delete(blowBack);
}
